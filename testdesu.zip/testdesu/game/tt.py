import sympy
a= sympy.Symbol('a')
print(a)